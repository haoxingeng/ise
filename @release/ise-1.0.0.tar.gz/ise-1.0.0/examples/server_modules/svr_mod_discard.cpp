///////////////////////////////////////////////////////////////////////////////

#include "svr_mod_discard.h"

///////////////////////////////////////////////////////////////////////////////

void ServerModule_Discard::onTcpConnected(const TcpConnectionPtr& connection)
{
    logger().writeFmt("onTcpConnected (%s) (ConnCount: %d)",
        connection->getPeerAddr().getDisplayStr().c_str(),
        connection->getServerConnCount());

    connection->recv(BYTE_PACKET_SPLITTER);
}

//-----------------------------------------------------------------------------

void ServerModule_Discard::onTcpDisconnected(const TcpConnectionPtr& connection)
{
    logger().writeFmt("onTcpDisconnected (%s)", connection->getConnectionName().c_str());
}

//-----------------------------------------------------------------------------

void ServerModule_Discard::onTcpRecvComplete(const TcpConnectionPtr& connection, void *packetBuffer,
    int packetSize, const Context& context)
{
    logger().writeFmt("[%s] Discarded %u bytes.",
        connection->getConnectionName().c_str(), packetSize);

    connection->recv(BYTE_PACKET_SPLITTER);
}
